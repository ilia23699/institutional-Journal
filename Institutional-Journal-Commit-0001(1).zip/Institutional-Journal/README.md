# Institutional Journal

MVP scaffold.
